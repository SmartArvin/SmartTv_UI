package com.test.realtimevideo;

public class AppConfig {
	public static int Port = 8000;// 音频端口
	public static int VPort = 6000;// 视频端口
}